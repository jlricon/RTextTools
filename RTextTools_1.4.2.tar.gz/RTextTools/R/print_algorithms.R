print_algorithms <- function() {
	algorithms <- c("BAGGING", "BOOSTING", "GLMNET", "MAXENT", "NNET", "RF", "SLDA", "SVM", "TREE")
	print(algorithms)
}