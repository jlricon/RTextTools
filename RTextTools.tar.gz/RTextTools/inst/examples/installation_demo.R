# AUTHOR: Timothy P. Jurka
# DESCRIPTION: Demonstrates installation of RTextTools.

# INSTALL RTextTools
install.packages("RTextTools")

# CHECK THAT EVERYTHING LOADS CORRECTLY
library(RTextTools)